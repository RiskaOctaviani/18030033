package com.example.modul5;

import android.content.Context;
import android.content.SharedPreferences;

public class sharedpreferences {
}
